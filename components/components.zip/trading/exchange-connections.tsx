"use client"

import { useState, useEffect } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Link2, ExternalLink, AlertTriangle, CheckCircle2, Info, ArrowLeft } from "lucide-react"
import {
  parseJsonPaste,
  validateApiKeyFormat,
  looksLikeJson,
  sanitizeApiKey,
  sanitizePrivateKey,
} from "@/lib/utils/api-key-validation"
import {
  CoinbaseApiFamily,
  coinbaseApis,
  coinbaseSandboxApis,
  getCoinbaseConfigsByFamily,
} from "@/lib/exchanges/coinbase/schema"

const EXCHANGES = [
  {
    id: "kraken",
    name: "Kraken",
    icon: "🐙",
    instructions: "Go to Account → Settings → API → Create API Key",
    apiKeyUrl: "https://www.kraken.com/u/security/api",
    requiresPassphrase: false,
    supportsApiFamilies: false,
  },
  {
    id: "binance_us",
    name: "Binance US",
    icon: "🟡",
    instructions: "Go to Account → API Management → Create API",
    apiKeyUrl: "https://www.binance.us/en/my/settings/api-management",
    requiresPassphrase: false,
    supportsApiFamilies: false,
  },
  {
    id: "coinbase",
    name: "Coinbase",
    icon: "🔵",
    instructions: "Select which Coinbase API you want to connect",
    apiKeyUrl: "https://www.coinbase.com/settings/api",
    requiresPassphrase: false,
    supportsApiFamilies: true,
    apiFamilies: [
      {
        id: "coinbase_advanced_trade",
        name: "Advanced Trade",
        description: "Retail trading (spot/futures) - Recommended for trading bots",
        family: CoinbaseApiFamily.ADVANCED_TRADE,
        instructions: "Go to Coinbase → Settings → API → Create API Key (CDP format with name/privateKey)",
        apiKeyUrl: "https://portal.cdp.coinbase.com/access/api",
      },
      {
        id: "coinbase_exchange",
        name: "Exchange (Institutional)",
        description: "Institutional trading - Separate Exchange account required",
        family: CoinbaseApiFamily.EXCHANGE,
        instructions: "Go to Exchange account → API Settings → Create API Key",
        apiKeyUrl: "https://exchange.coinbase.com/settings/api",
      },
      {
        id: "coinbase_app",
        name: "App API (Retail)",
        description: "Wallets, balances, fiat on/off ramp - No trading",
        family: CoinbaseApiFamily.APP,
        instructions: "Go to Coinbase → Settings → API → OAuth or CDP key",
        apiKeyUrl: "https://www.coinbase.com/settings/api",
      },
      {
        id: "coinbase_pro",
        name: "Pro (Legacy)",
        description: "Legacy Coinbase Pro API - Deprecated, use Advanced Trade instead",
        family: CoinbaseApiFamily.ADVANCED_TRADE, // Maps to Advanced Trade
        instructions: "Legacy format - Consider migrating to Advanced Trade",
        apiKeyUrl: "https://pro.coinbase.com/profile/api",
        isDeprecated: true,
      },
    ],
  },
]

export function ExchangeConnections() {
  const [connections, setConnections] = useState<any[]>([])
  const [open, setOpen] = useState(false)
  const [step, setStep] = useState<"select" | "apiFamily" | "credentials" | "instructions">("select")
  const [selectedExchange, setSelectedExchange] = useState("")
  const [selectedCoinbaseFamily, setSelectedCoinbaseFamily] = useState<CoinbaseApiFamily | null>(null)
  const [apiKey, setApiKey] = useState("")
  const [apiSecret, setApiSecret] = useState("")
  const [apiPassphrase, setApiPassphrase] = useState("")
  const [isTestnet, setIsTestnet] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchConnections()
  }, [])

  async function fetchConnections() {
    try {
      const response = await fetch("/api/v1/exchanges/connect")
      const data = await response.json()

      if (data.data) {
        setConnections(data.data)
      }
    } catch (error) {
      console.error("[v0] Error fetching exchange connections:", error)
    }
  }

  async function handleConnect() {
    if (!selectedExchange || !apiKey || !apiSecret) {
      setError("Please fill in all required fields")
      return
    }

    // Check if user pasted JSON
    let finalApiKey = apiKey
    let finalApiSecret = apiSecret
    let finalApiPassphrase = apiPassphrase

    // Try to parse as JSON if it looks like JSON
    if (looksLikeJson(apiKey) || looksLikeJson(apiSecret)) {
      const parsed = parseJsonPaste(apiKey || apiSecret)
      if (parsed) {
        if (parsed.warnings.length > 0 && !parsed.apiKey) {
          setError(parsed.warnings[0])
          return
        }
        if (parsed.apiKey) finalApiKey = parsed.apiKey
        if (parsed.apiSecret) finalApiSecret = parsed.apiSecret
        if (parsed.apiPassphrase) finalApiPassphrase = parsed.apiPassphrase
      }
    }

    // Determine the actual exchange name for validation
    let validationExchangeName = selectedExchange
    if (selectedExchange === "coinbase" && selectedCoinbaseFamily) {
      switch (selectedCoinbaseFamily) {
        case CoinbaseApiFamily.ADVANCED_TRADE:
          validationExchangeName = "coinbase_advanced_trade"
          break
        case CoinbaseApiFamily.EXCHANGE:
          validationExchangeName = "coinbase_exchange"
          break
        case CoinbaseApiFamily.APP:
          validationExchangeName = "coinbase_app"
          break
        case CoinbaseApiFamily.SERVER_WALLET:
          validationExchangeName = "coinbase_server_wallet"
          break
        case CoinbaseApiFamily.TRADE_API:
          validationExchangeName = "coinbase_trade_api"
          break
      }
    }

    // Validate and sanitize credentials
    const validation = validateApiKeyFormat(validationExchangeName, finalApiKey, finalApiSecret, finalApiPassphrase)

    if (!validation.isValid) {
      setError(validation.error || "Invalid API key format")
      return
    }

    // Update form fields with sanitized values
    if (validation.sanitized.apiKey !== finalApiKey) {
      setApiKey(validation.sanitized.apiKey)
      finalApiKey = validation.sanitized.apiKey
    }
    if (validation.sanitized.apiSecret !== finalApiSecret) {
      // Check if it's a PEM key to preserve formatting in the UI
      const isPemKey = validation.sanitized.apiSecret.includes("BEGIN") && validation.sanitized.apiSecret.includes("PRIVATE KEY")
      if (isPemKey) {
        // For PEM keys, we want to show them properly formatted
        setApiSecret(validation.sanitized.apiSecret)
      } else {
        setApiSecret(validation.sanitized.apiSecret)
      }
      finalApiSecret = validation.sanitized.apiSecret
    }
    if (validation.sanitized.apiPassphrase && validation.sanitized.apiPassphrase !== finalApiPassphrase) {
      setApiPassphrase(validation.sanitized.apiPassphrase)
      finalApiPassphrase = validation.sanitized.apiPassphrase
    }

    // Show warnings if any
    if (validation.warnings.length > 0) {
      const warningMessage = validation.warnings.join(" ")
      // Show warning but allow continuation
      console.warn("[v0] API Key validation warnings:", warningMessage)
    }

    const exchange = EXCHANGES.find((e) => e.id === selectedExchange)
    if (exchange?.requiresPassphrase && !finalApiPassphrase) {
      setError("API Passphrase is required for Coinbase Pro")
      return
    }

    setError(null)
    setLoading(true)
    
    // Determine the actual exchange name to use
    let actualExchangeName = selectedExchange
    if (selectedExchange === "coinbase" && selectedCoinbaseFamily) {
      // Map Coinbase API family to exchange name
      switch (selectedCoinbaseFamily) {
        case CoinbaseApiFamily.ADVANCED_TRADE:
          actualExchangeName = "coinbase_advanced_trade"
          break
        case CoinbaseApiFamily.EXCHANGE:
          actualExchangeName = "coinbase_exchange"
          break
        case CoinbaseApiFamily.APP:
          actualExchangeName = "coinbase_app"
          break
        case CoinbaseApiFamily.SERVER_WALLET:
          actualExchangeName = "coinbase_server_wallet"
          break
        case CoinbaseApiFamily.TRADE_API:
          actualExchangeName = "coinbase_trade_api"
          break
      }
    }
    
    try {
      const response = await fetch("/api/v1/exchanges/connect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          exchangeName: actualExchangeName,
          apiKey: finalApiKey,
          apiSecret: finalApiSecret,
          apiPassphrase: finalApiPassphrase || undefined,
          isTestnet,
          coinbaseApiFamily: selectedCoinbaseFamily || undefined,
        }),
      })

      const data = await response.json()

      if (data.success) {
        // Reset form
        setOpen(false)
        setStep("select")
        setApiKey("")
        setApiSecret("")
        setApiPassphrase("")
        setSelectedExchange("")
        setSelectedCoinbaseFamily(null)
        setIsTestnet(false)
        setError(null)
        fetchConnections()
      } else {
        setError(data.error || "Failed to connect exchange")
      }
    } catch (error: any) {
      console.error("[v0] Error connecting exchange:", error)
      setError(error.message || "Failed to connect exchange")
    } finally {
      setLoading(false)
    }
  }

  function handleSelectExchange(exchangeId: string) {
    setSelectedExchange(exchangeId)
    const exchange = EXCHANGES.find((e) => e.id === exchangeId)
    if (exchange?.supportsApiFamilies) {
      setStep("apiFamily")
    } else {
      setStep("instructions")
    }
    setError(null)
  }

  function handleSelectCoinbaseFamily(family: CoinbaseApiFamily) {
    setSelectedCoinbaseFamily(family)
    setStep("instructions")
    setError(null)
  }

  function handleBack() {
    if (step === "credentials") {
      setStep("instructions")
    } else if (step === "instructions") {
      const exchange = EXCHANGES.find((e) => e.id === selectedExchange)
      if (exchange?.supportsApiFamilies) {
        setStep("apiFamily")
      } else {
        setStep("select")
        setSelectedExchange("")
      }
    } else if (step === "apiFamily") {
      setStep("select")
      setSelectedExchange("")
      setSelectedCoinbaseFamily(null)
    }
    setError(null)
  }

  const selectedExchangeInfo = EXCHANGES.find((e) => e.id === selectedExchange)

  function handleDialogChange(isOpen: boolean) {
    setOpen(isOpen)
    if (!isOpen) {
      // Reset form when dialog closes
      setStep("select")
      setSelectedExchange("")
      setApiKey("")
      setApiSecret("")
      setApiPassphrase("")
      setIsTestnet(false)
      setError(null)
    }
  }

  return (
    <div className="flex items-center gap-2">
      <Dialog open={open} onOpenChange={handleDialogChange}>
        <DialogTrigger asChild>
          <Button variant="outline" className="gap-2 bg-transparent">
            <Link2 className="w-4 h-4" />
            Exchanges ({connections.length})
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Connect Exchange</DialogTitle>
            <DialogDescription>
              {step === "select" && "Select an exchange to connect"}
              {step === "apiFamily" && "Select which Coinbase API to use"}
              {step === "instructions" && "Follow the setup instructions"}
              {step === "credentials" && "Enter your API credentials"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Step 1: Select Exchange */}
            {step === "select" && (
              <div className="grid grid-cols-2 gap-3">
                {EXCHANGES.map((exchange) => (
                  <Card
                    key={exchange.id}
                    className="p-4 cursor-pointer hover:bg-muted/50 transition-colors border-2 hover:border-primary"
                    onClick={() => handleSelectExchange(exchange.id)}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{exchange.icon}</span>
                      <div className="flex-1">
                        <span className="font-semibold block">{exchange.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {exchange.requiresPassphrase ? "Requires passphrase" : "Standard API"}
                        </span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {/* Step 1.5: Select Coinbase API Family */}
            {step === "apiFamily" && selectedExchange === "coinbase" && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">🔵</span>
                    <span className="font-semibold text-lg">Coinbase</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleBack}>
                    <ArrowLeft className="h-4 w-4 mr-1" />
                    Back
                  </Button>
                </div>

                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertTitle>Choose Coinbase API</AlertTitle>
                  <AlertDescription className="mt-2 text-sm">
                    Coinbase offers multiple APIs with different capabilities. Select the one that matches your use case.
                  </AlertDescription>
                </Alert>

                <div className="grid gap-3">
                  {EXCHANGES.find((e) => e.id === "coinbase")?.apiFamilies?.map((family) => (
                    <Card
                      key={family.id}
                      className={`p-4 cursor-pointer hover:bg-muted/50 transition-colors border-2 ${
                        selectedCoinbaseFamily === family.family
                          ? "border-primary bg-primary/5"
                          : "hover:border-primary/50"
                      } ${family.isDeprecated ? "opacity-60" : ""}`}
                      onClick={() => handleSelectCoinbaseFamily(family.family)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold">{family.name}</span>
                            {family.isDeprecated && (
                              <Badge variant="outline" className="text-xs">
                                Deprecated
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{family.description}</p>
                        </div>
                        {selectedCoinbaseFamily === family.family && (
                          <CheckCircle2 className="h-5 w-5 text-primary" />
                        )}
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Step 2: Instructions */}
            {step === "instructions" && selectedExchangeInfo && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{selectedExchangeInfo.icon}</span>
                    <div>
                      <span className="font-semibold text-lg block">
                        {selectedExchangeInfo.name}
                        {selectedCoinbaseFamily &&
                          EXCHANGES.find((e) => e.id === "coinbase")?.apiFamilies?.find(
                            (f) => f.family === selectedCoinbaseFamily
                          )?.name && (
                            <span className="text-sm font-normal text-muted-foreground ml-2">
                              -{" "}
                              {
                                EXCHANGES.find((e) => e.id === "coinbase")?.apiFamilies?.find(
                                  (f) => f.family === selectedCoinbaseFamily
                                )?.name
                              }
                            </span>
                          )}
                      </span>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleBack}>
                    <ArrowLeft className="h-4 w-4 mr-1" />
                    Back
                  </Button>
                </div>

                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertTitle>Setup Instructions</AlertTitle>
                  <AlertDescription className="mt-2">
                    <ol className="list-decimal list-inside space-y-2 text-sm">
                      <li>
                        {selectedCoinbaseFamily &&
                        EXCHANGES.find((e) => e.id === "coinbase")?.apiFamilies?.find(
                          (f) => f.family === selectedCoinbaseFamily
                        )
                          ? EXCHANGES.find((e) => e.id === "coinbase")?.apiFamilies?.find(
                              (f) => f.family === selectedCoinbaseFamily
                            )?.instructions
                          : selectedExchangeInfo.instructions}
                      </li>
                      <li>
                        Configure API permissions:
                        <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                          <li>
                            <strong>Read:</strong> Required (to view balances and orders)
                          </li>
                          <li>
                            <strong>Trade:</strong> Required (to place orders)
                          </li>
                          <li>
                            <strong>Withdraw:</strong> Not recommended (for security)
                          </li>
                        </ul>
                      </li>
                      <li>
                        Copy your API Key, Secret
                        {selectedExchangeInfo.requiresPassphrase && ", and Passphrase"}
                        {selectedCoinbaseFamily === CoinbaseApiFamily.ADVANCED_TRADE &&
                          " (modern format: paste JSON with name + privateKey)"}
                      </li>
                      <li>Click "Continue" to enter credentials</li>
                    </ol>
                  </AlertDescription>
                </Alert>

                <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
                  <ExternalLink className="h-4 w-4 text-muted-foreground" />
                  <a
                    href={
                      selectedCoinbaseFamily &&
                      EXCHANGES.find((e) => e.id === "coinbase")?.apiFamilies?.find(
                        (f) => f.family === selectedCoinbaseFamily
                      )?.apiKeyUrl
                        ? EXCHANGES.find((e) => e.id === "coinbase")?.apiFamilies?.find(
                            (f) => f.family === selectedCoinbaseFamily
                          )?.apiKeyUrl || selectedExchangeInfo.apiKeyUrl
                        : selectedExchangeInfo.apiKeyUrl
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-primary hover:underline"
                  >
                    Open{" "}
                    {selectedCoinbaseFamily &&
                    EXCHANGES.find((e) => e.id === "coinbase")?.apiFamilies?.find(
                      (f) => f.family === selectedCoinbaseFamily
                    )
                      ? EXCHANGES.find((e) => e.id === "coinbase")?.apiFamilies?.find(
                          (f) => f.family === selectedCoinbaseFamily
                        )?.name
                      : selectedExchangeInfo.name}{" "}
                    API Settings
                  </a>
                </div>

                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Security Warning</AlertTitle>
                  <AlertDescription className="mt-2 text-sm">
                    Never share your API keys. We encrypt and store them securely. Only enable the minimum permissions
                    needed (Read + Trade, not Withdraw).
                  </AlertDescription>
                </Alert>

                <div className="flex items-center space-x-2 p-3 rounded-lg border">
                  <Checkbox
                    id="testnet"
                    checked={isTestnet}
                    onCheckedChange={(checked) => setIsTestnet(checked === true)}
                  />
                  <Label htmlFor="testnet" className="text-sm cursor-pointer">
                    Use testnet/sandbox environment (for testing only)
                  </Label>
                </div>

                <Button className="w-full" onClick={() => setStep("credentials")}>
                  Continue to Credentials
                </Button>
              </div>
            )}

            {/* Step 3: Enter Credentials */}
            {step === "credentials" && selectedExchangeInfo && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{selectedExchangeInfo.icon}</span>
                    <span className="font-semibold">{selectedExchangeInfo.name}</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleBack}>
                    <ArrowLeft className="h-4 w-4 mr-1" />
                    Back
                  </Button>
                </div>

                {error && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Connection Failed</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="apiKey">API Key *</Label>
                  <Input
                    id="apiKey"
                    type="text"
                    value={apiKey}
                    onChange={(e) => {
                      const value = e.target.value
                      setApiKey(value)
                      
                      // Auto-detect and parse JSON if pasted
                      if (looksLikeJson(value)) {
                        const parsed = parseJsonPaste(value)
                        if (parsed) {
                          if (parsed.warnings.length > 0 && !parsed.apiKey) {
                            setError(parsed.warnings[0])
                            return
                          }
                          if (parsed.apiKey) {
                            setApiKey(parsed.apiKey)
                            if (parsed.apiSecret) setApiSecret(parsed.apiSecret)
                            if (parsed.apiPassphrase) setApiPassphrase(parsed.apiPassphrase)
                            setError(null)
                          }
                        }
                      }
                    }}
                    onPaste={(e) => {
                      // Handle paste event to detect JSON
                      const pastedText = e.clipboardData.getData("text")
                      if (looksLikeJson(pastedText)) {
                        const parsed = parseJsonPaste(pastedText)
                        if (parsed) {
                          e.preventDefault()
                          if (parsed.warnings.length > 0 && !parsed.apiKey) {
                            setError(parsed.warnings[0])
                            return
                          }
                          if (parsed.apiKey) {
                            setApiKey(parsed.apiKey)
                            if (parsed.apiSecret) setApiSecret(parsed.apiSecret)
                            if (parsed.apiPassphrase) setApiPassphrase(parsed.apiPassphrase)
                            setError(null)
                          }
                        }
                      }
                    }}
                    placeholder="Enter your API key (or paste JSON)"
                    disabled={loading}
                  />
                  <p className="text-xs text-muted-foreground">
                    You can paste a JSON object with credentials - we'll extract them automatically. 
                    Supports both legacy format (apiKey/apiSecret) and modern format (name/privateKey).
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="apiSecret">API Secret *</Label>
                  <Input
                    id="apiSecret"
                    type="password"
                    value={apiSecret}
                    onChange={(e) => setApiSecret(e.target.value)}
                    placeholder="Enter your API secret"
                    disabled={loading}
                  />
                </div>

                {selectedExchangeInfo.requiresPassphrase && (
                  <div className="space-y-2">
                    <Label htmlFor="apiPassphrase">API Passphrase *</Label>
                    <Input
                      id="apiPassphrase"
                      type="password"
                      value={apiPassphrase}
                      onChange={(e) => setApiPassphrase(e.target.value)}
                      placeholder="Enter your API passphrase"
                      disabled={loading}
                    />
                    <p className="text-xs text-muted-foreground">
                      Required for Coinbase Pro API connections
                    </p>
                  </div>
                )}

                <div className="flex items-center space-x-2 p-3 rounded-lg border bg-muted/30">
                  <Checkbox
                    id="testnet-credentials"
                    checked={isTestnet}
                    onCheckedChange={(checked) => setIsTestnet(checked === true)}
                    disabled={loading}
                  />
                  <Label htmlFor="testnet-credentials" className="text-sm cursor-pointer">
                    Testnet/Sandbox mode
                  </Label>
                </div>

                <Button className="w-full" onClick={handleConnect} disabled={loading}>
                  {loading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2 inline-block" />
                      Testing connection...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      Connect Exchange
                    </>
                  )}
                </Button>
              </div>
            )}
          </div>

          {connections.length > 0 && (
            <div className="space-y-2 pt-4 border-t">
              <Label className="text-sm font-medium">Connected Exchanges</Label>
              <div className="space-y-2">
                {connections.map((conn) => (
                  <div
                    key={conn.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold capitalize">
                        {conn.exchange_name.replace("_", " ")}
                      </span>
                      <Badge variant={conn.is_active ? "default" : "secondary"} className="text-xs">
                        {conn.is_active ? "Active" : "Inactive"}
                      </Badge>
                      {conn.is_testnet && (
                        <Badge variant="outline" className="text-xs">
                          Testnet
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
